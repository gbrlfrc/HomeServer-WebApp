var demo = new Vue({
    el: '#demo',
    data: {
        showAnimationFor: {
            a: false,
            b: false,
            c: false,
            d: false
        }
    },
    methods: {
        isViewableNow(isVisible, entry, section) {
            this.showAnimationFor[section] = isVisible;
        }
    }
});

var demo = new Vue({
    el: '#demo2',
    data: {
        showAnimationFor: {
            a: false,
            b: false,
        }
    },
    methods: {
        isViewableNow(isVisible, entry, section) {
            this.showAnimationFor[section] = isVisible;
        }
    }
});
